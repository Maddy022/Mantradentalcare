import { Testimonial } from "@/lib/data";
import { Star, CheckCircle2 } from "lucide-react";

interface ReviewCardProps {
  testimonial: Testimonial;
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
      />
    </svg>
  );
}

export function ReviewCard({ testimonial }: ReviewCardProps) {
  const avatarColors = [
    "bg-emerald-100 text-emerald-800 border-emerald-300",
    "bg-teal-100 text-teal-800 border-teal-300",
    "bg-cyan-100 text-cyan-800 border-cyan-300",
    "bg-amber-100 text-amber-800 border-amber-300",
    "bg-indigo-100 text-indigo-800 border-indigo-300",
  ];

  const colorIndex = (testimonial.name.charCodeAt(0) || 0) % avatarColors.length;
  const avatarColor = avatarColors[colorIndex];

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-xs hover:shadow-xl transition-all duration-300 border border-border hover:border-primary flex flex-col h-full justify-between group hover:-translate-y-1">
      <div>
        {/* Top Header: Author Avatar & Google Badge */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-full font-bold font-heading flex items-center justify-center border text-base ${avatarColor}`}>
              {testimonial.name.charAt(0)}
            </div>
            <div>
              <p className="font-bold text-text-primary text-sm sm:text-base flex items-center gap-1.5">
                <span>{testimonial.name}</span>
                <CheckCircle2 className="w-4 h-4 text-primary fill-primary/10" />
              </p>
              <p className="text-[11px] text-text-secondary">Verified Google Review • {testimonial.date}</p>
            </div>
          </div>

          <div className="w-8 h-8 rounded-full bg-surface flex items-center justify-center border border-border shrink-0 shadow-2xs">
            <GoogleIcon className="w-4 h-4" />
          </div>
        </div>

        {/* 5 Stars */}
        <div className="flex items-center gap-1 mb-4">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={`w-4 h-4 ${
                star <= testimonial.rating
                  ? "fill-amber-400 text-amber-400"
                  : "fill-gray-200 text-gray-200"
              }`}
            />
          ))}
          <span className="text-xs font-bold text-text-primary ml-1.5">{testimonial.rating.toFixed(1)}</span>
        </div>

        {/* Review Text */}
        <p className="text-text-secondary text-sm leading-relaxed mb-4">
          &quot;{testimonial.text}&quot;
        </p>
      </div>

      {/* Footer Tag */}
      <div className="pt-3 border-t border-border/60 mt-auto flex items-center justify-between text-xs text-text-secondary">
        <span className="font-medium">Mantra Dental Care, Rajkot</span>
        <span className="text-primary font-semibold">Google Verified</span>
      </div>
    </div>
  );
}
