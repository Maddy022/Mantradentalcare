import { NextResponse } from "next/server";
import { testimonials } from "@/lib/data";

export async function GET() {
  // TODO: In a production app, integrate with Google Places API to fetch real reviews.
  // Example: 
  // const res = await fetch(`https://maps.googleapis.com/maps/api/place/details/json?place_id=YOUR_PLACE_ID&fields=reviews,rating,user_ratings_total&key=${process.env.GOOGLE_PLACES_API_KEY}`);
  // const data = await res.json();
  
  // For now, return mock data from testimonials
  
  return NextResponse.json(
    { 
      rating: 5.0, 
      reviewCount: 133, 
      reviews: testimonials 
    },
    { status: 200 }
  );
}
